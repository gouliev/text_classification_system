/* jQuery javascript functions for framed pages */
var gIsFrameset = true;

$(document).ready(function() {

	fixFrameLinks($("a,form"));
	
});
